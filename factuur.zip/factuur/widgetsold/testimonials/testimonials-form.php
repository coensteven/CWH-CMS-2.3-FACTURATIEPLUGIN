<?php defined('PF_VERSION') OR header('Location:404.html'); ?>
<div class="form-group">
    <label for="title"><?php echo __('Widget Title','testimonials'); ?></label>
    <div><?php echo form_input(array('name'=>'widget-title','id'=>'widget-title')); ?></div>
</div>
